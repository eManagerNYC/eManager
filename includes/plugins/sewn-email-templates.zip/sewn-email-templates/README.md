# Sewn In Email Templates

Wordpress plugin that adds an HTML template system for emails to make them prettier and more useable.

## Custom templates for your theme

Copy the "templates" folder into your theme and rename it "sewn-email-templates"
