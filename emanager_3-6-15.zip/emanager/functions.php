<?php

/**
 * Set up the theme
 */
if ( ! defined('DISALLOW_FILE_EDIT') ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

function eman_info( $key, $esc='html' )
{
	static $version  = null;
	static $params   = null;
	$info            = array(
		'creator'            => 'Matthew M. Emma',
		'creatorurl'         => null,
		'partner'            => 'John F. Glatt',
		'partnerurl'         => null,
		'angel'              => 'Mark J. Pulsfort',
		'angelurl'           => null,
		'company'            => 'eManager',
		'companyurl'         => 'http://emanagertcco.com/',
		'parentcompany'      => 'Turner Construction Co.',
		'parentcompanyurl'   => 'http://www.turnerconstruction.com/',
		'sitename'           => get_option('blogname'),
		'dashboard_colors'   => array( 'babyblue', 'navy', 'orange', 'verde' ),
		'company_post_types' => array( 'em_employees', 'em_equipment', 'em_labortypes', 'em_materials' ),
	);
	static $raw_items = array('dashboard_colors', 'company_post_types');
	static $url_items = array('creatorurl', 'partnerurl', 'angelurl', 'companyurl', 'parentcompanyurl');

	// Dynamic items
	if ( 'version' == $key )
	{
		if ( null === $version )
		{
			$theme = wp_get_theme();
			$version = $theme->Version;
		}
		return $version;
	}
	elseif ( 'support_params' == $key )
	{
		if ( null === $params )
		{
			$user    = wp_get_current_user();
			$subject = 'eManager Support';
			$params = array(
				'referred' => str_replace(array('https://','http://'), '', home_url()),
				'view'     => get_permalink(),
				'subject'  => $subject,
				'user'     => eman_users_name( $user ),
				'email'    => $user->user_email,
			);
			foreach ( $params as &$param ) {
				$param = urlencode($param);
			}
		}
		return $params;
	}

	// If empty, nothing left to do
	if ( empty($info[$key]) ) { return false; }

	// Raw content return
	if ( in_array($key, $raw_items) ) {
		return $info[$key];
	}

	// URL content return
	if ( in_array($key, $url_items) ) {
		return esc_url_raw($info[$key]);
	}

	// Create an anchor link if entry has a url
	if ( 'link' == $esc ) {
		if ( ! empty($info["{$key}url"]) ) {
			return '<a href="' . esc_url_raw($info["{$key}url"]) . '" title="Visit ' . esc_attr($info[$key]) . '" targe="_blank">' . esc_html($info[$key]) . '</a>';
		} else {
			return esc_html($info[$key]);
		}
	// URL escape
	} elseif ( 'url' == $esc ) {
		return esc_url_raw($info[$key]);
	// attribute escape
	} elseif ( 'attr' == $esc ) {
		return esc_attr($info[$key]);
	// Raw escape
	} elseif ( false == $esc ) {
		return $info[$key];
	// HTML escape
	} else {
		return esc_html($info[$key]);
	}
}


/**
 * Retrieve the eManager url.
 *
 * @author Jake Snyder
 * @param  string $path   Optional. Path relative to the eManager url. Default empty.
 * @return string eManager url link with optional path appended.
 */
function emanager_url( $path = '' )
{
	if ( $url = trailingslashit(eman_info('companyurl')) ) {
		return $url . (is_string($path) ? ltrim($path,'/') : '');
	}
}


/**
 * Load basic modules
 *
 * Comment out modules that are not desired for the current site.
 */

// Admin
require_once( 'admin/admin.php' );
require_once( 'admin/login.php' );
require_once( 'admin/tinymce.php' );
require_once( 'admin/upgrades.php' );
#require_once( 'admin/dashboard-widget.php' ); 			// A basic example to show instructions
#require_once( 'admin/recently-updated-content.php' ); 	// Shows recently updated content. REQUIRES customization
require_once( 'admin/required_plugins.php' );           // Manage requirements

// Front end
require_once( 'includes/mobile.php' );
#require_once( 'includes/nice-search.php' );			// Clean search urls
#require_once( 'includes/assets-rewrites.php' );		// Rewrite theme assets to /assets and plugins to /plugins. DOES NOT WORK ON NGINX SERVERS LIKE WPENGINE
require_once( 'includes/settings/enqueue.php' );


/**
 * Load emanager modules
 */

// Install settings, generally each install runs once
require_once( 'includes/install.php' );
require_once( 'includes/acf-wrapper.php' );

// Add the rest of the functionality
#require_once( 'includes/plugins.php' );
require_once( 'includes/post_types.php' );
require_once( 'includes/settings.php' );
require_once( 'includes/classes.php' );
require_once( 'includes/save.php' );
require_once( 'includes/field_support.php' );
require_once( 'includes/components.php' );


/**
 * Theme updates
 */
require_once( 'includes/updates/updates.php' );


/**
 * Customize Site
 */

add_filter( 'wp_list_pages', 'eman_nav_update', 10, 2 );
function eman_nav_update( $output, $r )
{
	// Switch Dashboard out with icon
	$output = str_replace( '>Dashboard</a>', '><span class="fa fa-home" aria-hidden="true"></span> Home</a>', $output );

	// Add messages indicator to Inbox
	ob_start();
	do_action( 'sewn/messenger/new_message_indicator', array('show_0' => false) );
	$indicator = ob_get_clean();
	$output = str_replace(">Inbox</a>", ">Inbox $indicator</a>", $output);

	return $output;
}


/**
 * Remove the content field from the title/content plugin
 */
add_filter( 'acf/edit_title_content/content/add', '__return_false' );
if ( false !== strpos($_SERVER['REQUEST_URI'], '/profile/') ) {
	add_filter( "sewn/register/username/add", '__return_false' );
}


/**
 * Add header image to emails
 */
add_filter( "sewn/email_templates/headerimage", 'eman_email_headerimage' );
function eman_email_headerimage()
{
	return get_template_directory_uri() . '/assets/img/email_header.jpg';
}

add_filter( "sewn/email_templates/headerimage_alt", 'eman_email_headerimage_alt' );
function eman_email_headerimage_alt()
{
	return 'eManager';
}