<article id="post-not-found" class="hentry clearfix">

	<header class="article-header">
		<h1>Page Not Found</h1>
	</header>

	<section class="entry-content">
		<p>Sorry, nothing to see here</p>
	</section>

</article>