<?php
/** /
if ( ! empty($_GET['autofill']) )
{
	add_filter( 'acf/field_group/get_fields', 'eman_add_values_to_fields' );
	function eman_add_values_to_fields( $fields )
	{
		$current_user = wp_get_current_user();

		$args    = array(
			'post_type'      => get_query_var('post_type'),
			'author'         => $current_user->ID,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'posts_per_page' => 1,
			'meta_key'       => 'company',
			'meta_value'     => $current_user->company,
		);
		$posts   = new WP_Query( $args );
		$post_id = $posts->post->ID;

		foreach ( $fields as $key => $field )
		{
			if ( ! in_array($field['name'], array('date','work_date')) )
			{
				$field['value']        = apply_filters('acf/load_value', false, $post_id, $field);
				$fields[$key]['value'] = apply_filters('acf/format_value', $field['value'], $post_id, $field);
			}
		}

		return $fields;
	}
}
/**/