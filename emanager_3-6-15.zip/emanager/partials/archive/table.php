<?php
$post_type = eman_archive_info('post_type');
$cpt       = eman_archive_info('cpt');
?>
<h2 class="m-9of12 first cf"><span class="modal-flowchart-container"><?php eman_flowchart($post_type); ?></span> <?php echo eman_archive_info('plural_title'); ?></h2>

<div class="tab-pane active" id="<?php echo $post_type ?>_records">

	<?php do_action( 'emanager_table_filters/filters', array( 'post_type' => $post_type ) ); ?>

	<?php
	$emanager_table = new emanager_table();
	echo $emanager_table->table( $posts );
	echo '<div class="pager">'.count($posts).' items</div>';
	?>

	<div id="table-export" class="m-all cf">
		<?php
		echo eman_button( array(
			'text'        => 'Export',
			'title'       => 'Download CSV export of current page',
			'url'         => add_query_arg( 'action', 'csv' ),
			'icon_before' => 'download',
			'size'        => 'mini',
			'target'      => '_blank',
		) );
		echo eman_button( array(
			'text'        => 'Export Month',
			'title'       => 'Download CSV export of current month records',
			'url'         => add_query_arg( array('action' => 'csv', 'type' => 'month') ),
			'icon_before' => 'download',
			'size'        => 'mini',
			'target'      => '_blank',
		) );
		echo eman_button( array(
			'text'        => 'Export All',
			'title'       => 'Download CSV export of ALL records',
			'url'         => add_query_arg( array('action' => 'csv', 'type' => 'all') ),
			'icon_before' => 'download',
			'size'        => 'mini',
			'target'      => '_blank',
		) );
		?>
	</div>

</div>
