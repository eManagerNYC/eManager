<?php
if ( ! empty($_GET['action']) && 'confirm' == $_GET['action'] && eman_can_edit($GLOBALS['post']) )
{
	/**
	 * Create a review
	 */
	$turner_responsible = get_post_meta($GLOBALS['post']->ID, 'turner_responsible', true);
	$review_id = emanager_bic::add_review( $turner_responsible );

	/**
	 * Update meta & email the superintendent
	 */
	if ( $review_id )
	{
		// Add post to review
		update_post_meta( $review_id, 'reviewed_id', $GLOBALS['post']->ID );

		// Mark confirmation
		update_post_meta( $review_id, 'confirm', current_time('timestamp') );

		// Update the review status
		if ( 'em_noc' == $GLOBALS['post']->post_type ) {
			$new_status = 'manager';
		} elseif ( 'em_issue' == $GLOBALS['post']->post_type ) {
			$new_status = 'open';
		} else {
			$new_status = 'superintendent';
		}
		wp_set_object_terms( $review_id, $new_status, 'em_status' );
		wp_set_object_terms( $GLOBALS['post']->ID, $new_status, 'em_status' );

		wp_redirect( add_query_arg('action', 'confirmed', get_permalink()) );
		die;
	}

	wp_redirect( add_query_arg('action', 'notconfirmed', get_permalink()) );
	die;
}