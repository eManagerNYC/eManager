					<div class="register_form cf">
						<h3 class="register_title">Register</h3>
						<?php do_action( 'sewn/register/the_form', array( 'field_groups' => array('acf_custom-register','acf_terms') ) ); ?>
					</div>