document.addEventListener( 'DOMContentLoaded', function() {

	var export_button = document.getElementsByClassName('table-export-all');

	// Handle each step of export
	function export_all( progress )
	{
		var data     = {
				action:       'eman_csv_export_all',
				post_type:    eman.post_type,
				query_string: eman.query_string,
			},
			callback = function( response ) {
				//console.log(response);
				response = JSON.parse( response );

				if ( response )
				{
					var progress_bar = progress.querySelector('.progress-bar');

					if ( 1 == response.status )
					{
						// Update the progress bar
						var progress_value        = (response.page / response.pages) * 100;
						progress_bar.classList.add('active');
						progress_bar.setAttribute('aria-valuenow', progress_value);
						progress_bar.innerHTML    = Math.round(progress_value) + '%';
						progress_bar.style.width  = Math.round(progress_value) + '%';

						// Keep going until done
						export_all( progress );
					}
					else
					{
						// Create the link
						var link                  = document.createElement('a'),
							filename_array        = response.url.split('/'),
							filename              = filename_array[filename_array.length-1];
							link.setAttribute('class', 'export_link');
							link.setAttribute('href', response.url);
							link.setAttribute('title', 'Download export');
							link.setAttribute('target', '_blank');
							link.setAttribute('download', filename);
							link.innerHTML        = 'Download';
							link.style.fontWeight = 'bold';
							link.style.color      = 'white';

						// Deactivate the progress bar
						progress_bar.classList.remove('active');
						progress_bar.innerHTML    = '';//'Complete';
						progress_bar.appendChild( link );
					}
				}
			};
		ajax.post( data, callback );
	};

	// Add click
	if ( export_button )
	{
		for ( var i=0; i<export_button.length; i++ )
		{
			export_button[i].addEventListener( 'click', function(e) {
				e.preventDefault();

				// Add the bootstrap progress bar
				var progress = document.createElement('div');
					progress.setAttribute('class', 'progress export_progress');
				var progress_bar = document.createElement("div");
					progress_bar.setAttribute('class', 'progress-bar progress-bar-warning progress-bar-striped');
					progress_bar.setAttribute('role', 'progressbar');
					progress_bar.setAttribute('aria-valuenow', 0);
					progress_bar.setAttribute('aria-valuemin', 0);
					progress_bar.setAttribute('aria-valuemax', 100);
				progress.appendChild( progress_bar );
				this.parentNode.appendChild( progress );

				export_all( progress );
			} );
		}
	}

});