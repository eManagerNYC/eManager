<?php

$classname = 'emanager_table_export';
if ( ! class_exists($classname) ) :

class emanager_table_export
{
	/**
	 * Class prefix
	 *
	 * @var 	string
	 */
	const PREFIX = __CLASS__;

	/**
	 * Construct
	 *
	 * @author  Jake Snyder
	 * @return	void
	 */
	public function __construct()
	{
		add_action( self::PREFIX . '/setup_export', array($this, 'setup_export') );
		add_action( 'wp_ajax_eman_csv_export_all', array($this, 'setup_export_ajax') );
	}




	/**
	 * setup_export
	 *
	 * Reads request variables and builds an export CSV when requested.
	 *
	 * @author  Jake Snyder
	 * @return	void
	 */
	public function setup_export()
	{
		if ( empty($_GET['action']) || 'csv' != $_GET['action'] ) return;

		global $query_string;

		$posts = array();
		if ( ! empty($_GET['type']) && 'all' == $_GET['type'] ) {
			$posts = get_posts( $query_string . '&posts_per_page=-1' );
		} elseif ( ! empty($_GET['type']) && 'month' == $_GET['type'] ) {
			$y = date_i18n('Y');
			$m = date_i18n('n');
			$new_wp_query = new WP_Query( wp_parse_args($query_string, array(
				'date_query' => array(
					array(
						'after'     => array(
							'year'  => $y,
							'month' => $m,
							'day'   => 1,
						),
						'before'    => array(
							'year'  => $y,
							'month' => $m,
							'day'   => date_i18n('t'),
						),
						'inclusive' => true,
					),
				),
				'posts_per_page' => -1,
			)) );
			if ( $new_wp_query ) {
				$posts = $new_wp_query->posts;
			}
		} else {
			$posts = $GLOBALS['posts'];
		}

		$args = array(
			'type'  => 'export',
			'cols'  => 'all',
		);

		$filename = post_type_archive_title(NULL, false) . '_' . date_i18n('Y_m_d-g_h_A', current_time('timestamp'));
		$fileType = "csv";

		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename=$filename.$fileType");

		#echo "<pre>\n";
		$table_class = new emanager_table();
		$table_class->table($posts, $args);
		#echo "</pre>\n";

		die;
	}

	/**
	 * Reads request variables and builds an export CSV when requested.
	 *
	 * @author  Jake Snyder
	 * @return	void
	 */
	public function setup_export_ajax()
	{
		if ( empty($_POST['post_type']) )    { die('No post type provided'); }
		if ( empty($_POST['query_string']) ) { die('No query string provided'); }

		// User object
		$current_user   = wp_get_current_user();

		// Settings
		$post_type      = $_POST['post_type'];
		$query_string   = $_POST['query_string'];
		wp_parse_str($query_string, $query_array);
		$posts_per_page = 10;#get_option('posts_per_page');
		$company        = get_post($current_user->company);
		$upload_dir     = wp_upload_dir();
		$base_dir       = $upload_dir['basedir'];
		$company_dir    = "{$upload_dir['basedir']}/Companies/{$company->post_title}/";
		$company_url    = "{$upload_dir['baseurl']}/Companies/{$company->post_title}/";
		$temp_dir       = "{$upload_dir['basedir']}/tmp/";
		$file_name      = '';
		$page           = 1;
		$meta_key       = $post_type . '_export_progress';
		$table_settings = array(
			'type'  => 'export',
			'cols'  => 'all',
		);

		// If no company, no where to save
		if ( ! $company ) { die('User could not be determined'); }

		// If no temp directory yet, create it
		if ( ! file_exists($temp_dir) ) {
			// If the directory can't be created, return
			if ( ! wp_mkdir_p( $temp_dir ) ) {
				die('Cannot create temporary directory');
			}
		}

		// Retrieve option for file if one exists, and parse it
		if ( $progress = get_metadata('user', $current_user->ID, $meta_key, true) )
		{
			if ( ! empty($progress['filename']) ) {
				$file_name = $progress['filename'];
			}
			if ( ! empty($progress['page']) ) {
				$page      = $progress['page'];
			}
		}

		// Or create filename and current page
		if ( ! $file_name ) {
			$file_name = "{$current_user->user_login}_{$post_type}_" . date_i18n('Y_m_d-g_h_A', current_time('timestamp')) . '.csv';
		}

		// Temporary file
		$file = $temp_dir . $file_name;

		// Try to get posts using page variable
		$posts = get_posts( $query_string . "&paged={$page}&posts_per_page={$posts_per_page}" );

		$query_args = array_merge( $query_array, array(
			'paged'          => $page,
			'posts_per_page' => $posts_per_page,
		) );
		$posts = new WP_Query( $query_args );
#die( json_encode($posts) );

		// If no posts
		if ( ! $posts->have_posts() )
		{
			// Make sure the temp file is moved to company folder
			if ( file_exists($file) ) {
				rename( $file, $company_dir . $file_name);
			}

			// Delete the database option
			delete_metadata( 'user', $current_user->ID, $meta_key );

			// Call it a day
			echo json_encode( array(
				'status' => 0,
				'url'    => $company_url . $file_name,
			) );
			die;
		}
		else
		{
			$mode = (1 == $page ? 'w' : 'a');
			// Try to open existing file
			$handle = fopen($file, $mode);// or die("Cannot open file: $file");
			// Otherwise try to create it
			if ( ! $handle ) {
				$handle = fopen($file, 'w') or die("Cannot create file: $file");
			}

			// Build the new rows
			ob_start();
			$table_class = new emanager_table();
			$table_class->table($posts->posts, $table_settings);
			$rows = ob_get_clean();
			fwrite($handle, $rows);
			fclose($handle);

			// Update progress in the user's meta
			update_metadata( 'user', $current_user->ID, $meta_key, array(
				'filename' => $file_name,
				'page'     => $page+1,
			) );

			// Return this segment
			echo json_encode( array(
				'count'    => $posts->post_count,
				'total'    => $posts->found_posts,
				'pages'    => $posts->max_num_pages,
				'status'   => 1,
				'filename' => $file_name,
				'page'     => $page,
			) );
			die;
		}
	}
}

$$classname = new $classname;

endif;
