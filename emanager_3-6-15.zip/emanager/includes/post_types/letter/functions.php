<?php

/**
 * Set status to "closed" via ajax
 */
add_action( 'wp_ajax_letter_close_button', 'eman_letter_close_button' );
function eman_letter_close_button()
{
	$status = false;
	if ( current_user_can('manage_options') && ! empty($_POST['letter_id']) ) {
		#wp_set_object_terms( $_POST['letter_id'], 'closed', 'em_status' );
		$current_user = wp_get_current_user();
		$review_id = emanager_bic::add_review( $current_user->ID, $_POST['letter_id'], 'closed' );
		$status = $review_id;
	}

	echo json_encode( array( 'status' => $status ) );
	die;
}