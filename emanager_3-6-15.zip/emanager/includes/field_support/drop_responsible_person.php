<?php

/**
 * Filter the responsible_person selectors
 */
add_filter( 'acf/create_field', 'eman_responsible_person', 1, 2 );
function eman_responsible_person( $field, $post_id=false )
{
	if ( 'field_bic_turner' != $field['key'] && 'field_bic_custom_approvers' != $field['key'] )
	{
		// Initial turner responsible field in PCO
		if ( (is_post_type_archive('em_noc') || ( ! empty($GLOBALS['post']) && 'em_noc' == $GLOBALS['post']->post_type)) && 'turner_responsible' == $field['_name'] && isset($field['choices']['Turner']) )
		{
			// reset choices
			$field['choices'] = array();
			$ticket_approvers = eman_get_field('pco_approvers', 'option');
			if ( is_array($ticket_approvers) )
			{
				foreach ( $ticket_approvers as $ticket_approver )
				{
					$field['choices'][ $ticket_approver['ID'] ] = $ticket_approver['display_name'];
				}
				if ( 2 > count($ticket_approvers) ) $field['allow_null'] = 0;
				do_action('acf/create_field', $field);
			}
			else
			{
				return $field;
			}
		}
		// Initial turner responsible field in DCR
		elseif ( (is_post_type_archive('em_dcr') || ( ! empty($GLOBALS['post']) && 'em_dcr' == $GLOBALS['post']->post_type)) && 'turner_responsible' == $field['_name'] && isset($field['choices']['Turner']) )
		{
			// reset choices
			$field['choices'] = array();
			$ticket_approvers = eman_get_field('dcr_reviewers', 'option');
			if ( is_array($ticket_approvers) )
			{
				foreach ( $ticket_approvers as $ticket_approver )
				{
					$field['choices'][ $ticket_approver['ID'] ] = $ticket_approver['display_name'];
				}
				if ( 2 > count($ticket_approvers) ) $field['allow_null'] = 0;
				do_action('acf/create_field', $field);
			}
			else
			{
				return $field;
			}
		}
		// Review "send to" field
		elseif ( (is_post_type_archive('em_noc') || ( ! empty($GLOBALS['post']) && 'em_noc' == $GLOBALS['post']->post_type)) && 'send_to' == $field['_name'] && isset($field['choices']['Turner']) )
		{
			// reset choices
			$field['choices'] = array();

			// get the textarea value from options page without any formatting
			$ticket_approvers = eman_get_field('noc_gatekeeper', 'option');

			if ( is_array($ticket_approvers) )
			{
				foreach ( $ticket_approvers as $ticket_approver )
				{
					$field['choices'][ $ticket_approver['ID'] ] = $ticket_approver['display_name'];
				}
			}
			if ( 2 > count($ticket_approvers) ) $field['allow_null'] = 0;
			do_action('acf/create_field', $field);
		}
		// Ticket "send to" field
		elseif ( (is_post_type_archive('em_tickets') || ( ! empty($GLOBALS['post']) && 'em_tickets' == $GLOBALS['post']->post_type)) && 'send_to' == $field['_name'] && isset($field['choices']['Turner']) )
		{
			// reset choices
			$field['choices'] = array();

			// get the textarea value from options page without any formatting
			$ticket_approvers = eman_get_field('ticket_approvers', 'option');

			if ( is_array($ticket_approvers) )
			{
				foreach ( $ticket_approvers as $ticket_approver )
				{
					$field['choices'][ $ticket_approver['ID'] ] = $ticket_approver['display_name'];
				}
			}
			if ( 2 > count($ticket_approvers) ) $field['allow_null'] = 0;
			do_action('acf/create_field', $field);
		}
	}

	return $field;
}