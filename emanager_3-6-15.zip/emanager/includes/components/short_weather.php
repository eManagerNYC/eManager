<?php
/**
 * Weather support
 */

class eman_weather
{
	public function __construct()
	{
		add_shortcode( 'weather', array($this, 'forecast') );
	}

	public function forecast( $atts )
	{
		extract( shortcode_atts( array(
			'city'  => 'New_York',
			'state' => 'NY',
			'days'  => '3',
			'm'     => 'F'
		), $atts, 'weather' ) );

		$apikey = eman_get_field('wunderground_api_key', 'option');
		$apiurl = 'http://api.wunderground.com/api/' . $apikey . '/forecast10day/q/' . ($state ? $state : 'NY') . '/' . $city . '.json';
		if ( ! ($json_string = @file_get_contents($apiurl)) )
		{
			return false;
		}

		$parsed_json = json_decode($json_string);
		$forecasts   = ( ! empty($parsed_json->forecast->simpleforecast->forecastday) ) ? $parsed_json->forecast->simpleforecast->forecastday : false;
		$start       = 0;
		$end         = $days;
		$weatherunit = '';

		if ( $forecasts )
		{
			for ($i = $start; $i < $end; $i++)
			{
				if ( empty($forecasts[$i]) ) {
					continue;
				}

				$forecast = $forecasts[$i];

				$cols = floor(100 / $days);
				if ( 'F' === $m ) {
					$temp = 'High: ' . ( ! empty($forecast->{'high'}->{'fahrenheit'}) ? $forecast->{'high'}->{'fahrenheit'} : '') . '&deg; Low: ' . ( ! empty($forecast->{'low'}->{'fahrenheit'}) ? $forecast->{'low'}->{'fahrenheit'} : '') . '&deg;F';
				}

				if ( 'C' === $m ) {
					$temp = 'High: ' . $forecast->{'high'}->{'celsius'} . '&deg;C Low: ' . $forecast->{'low'}->{'celsius'} . '&deg;C';
				}

				$weatherunit .= '<div class="weatherunit" style="float: left; width: '.$cols.'%"><small><center>';
				if ( ! empty($forecast->{'date'}->{'weekday'}) && ! empty($forecast->{'date'}->{'pretty'}) ) {
					$weatherunit .= $forecast->{'date'}->{'weekday'} . ', ' . substr(strstr($forecast->{'date'}->{'pretty'}, ' on '), 4) . '<br />';
				}
				if ( ! empty($forecast->{'conditions'}) ) {
					$weatherunit .= $this->forecast_icon($forecast->{'conditions'}, 42) . '<br>';
					$weatherunit .= $forecast->{'conditions'}.'<br>'.$temp;
				}
				$weatherunit .= '</center></small></div>';
			}
			return $weatherunit;
		}
	}

	private function forecast_icon( $status, $size=42 )
	{
		$icons = array(
			'Chance of Flurries'       => 'wi-day-snow',
			'Chance of Rain'           => 'wi-day-rain',
			'Chance Rain'              => 'wi-day-rain',
			'Chance of Freezing Rain'  => 'wi-day-rain-mix',
			'Chance of Sleet'          => 'wi-day-rain-mix',
			'Chance of Snow'           => 'wi-day-snow',
			'Chance of Thunderstorms'  => 'wi-day-thunderstorm',
			'Chance of a Thunderstorm' => 'wi-day-thunderstorm',
			'Clear'                    => 'wi-day-sunny',
			'Cloudy'                   => 'wi-day-cloudy',
			'Fog'                      => 'wi-smoke',
			'Haze'                     => 'wi-smog',
			'Mostly Cloudy'            => 'wi-day-cloudy',
			'Mostly Sunny'             => 'wi-day-sunny',
			'Partly Cloudy'            => 'wi-day-cloudy',
			'Partly Sunny'             => 'wi-day-sunny',
			'Freezing Rain'            => 'wi-day-rain-mix',
			'Rain'                     => 'wi-rain',
			'Sleet'                    => 'wi-rain-mix',
			'Snow'                     => 'wi-snow',
			'Sunny'                    => 'wi-day-sunny',
			'Thunderstorms'            => 'wi-thunderstorm',
			'Thunderstorm'             => 'wi-thunderstorm',
			'Unknown'                  => 'wi-sunny',
			'Overcast'                 => 'wi-day-sunny-overcast',
			'Scattered Clouds'         => 'wi-day-cloudy',
		);
		if ( ! empty($icons[$status]) ) {
			return '<span style="font-size: ' . $size . 'px;" class="' . $icons[$status] . '" aria-hidden="true"></span>';
		}
	}
}

class eman_weather_history
{
	public function __construct()
	{
		add_shortcode( 'weather_history', array($this, 'history') );
	}

	public function history( $atts )
	{
		extract( shortcode_atts( array(
			'city'  => 'New_York',
			'state' => 'NY',
			'y'     => '1986',
			'm'     => '11',
			'd'     => '27',
			'icon'  => 72,
			'deg'   => 'F'
		), $atts, 'hw' ) );

		$apikey       = eman_get_field('wunderground_api_key', 'option');
		$json_string  = file_get_contents('http://api.wunderground.com/api/'.$apikey.'/history_' . $y . $m . $d . '/q/' . $state . '/' . $city . '.json');
		$parsed_json  = json_decode($json_string);
		$dailysummary = $parsed_json->{'history'}->{'dailysummary'}[0];
		$observations = $parsed_json->{'history'}->{'observations'};
		$obsarray     = array();
		$hourSearch   = 6;

		foreach ($observations as $observation) {
			$hour = $observation->{'date'}->{'hour'};
			if ($hour == $hourSearch) {
				array_push($obsarray, $observation);
				$hourSearch += 6;
			}
		}

		$weatherunit = '<div class="historicalweather"><div class="wgroup">';
  
		foreach ($obsarray as $obs) {
			$cols = floor(100 / count($obsarray) );
			$weatherunit .= '<div class="time" style="float: left; text-align: center; width: ' . $cols . '%">'
				. str_replace(' on ', '<br>', $obs->{'date'}->{'pretty'}) . '<br><br>'
				. $this->history_icon($obs->{'conds'}, $icon)
				. '<br><br>' . $obs->{'conds'} . '</div>';
		}

		if ( 'F' === $m ) {
			$temperature = 'Low: ' . $dailysummary->{'mintempi'} . '&deg;F, High: ' . $dailysummary->{'maxtempi'} . '&deg;F';
		}

		if ( 'C' === $m ) {
			$temperature = 'Low: ' . $dailysummary->{'mintempm'} . '&deg;C, High: ' . $dailysummary->{'maxtempm'} . '&deg;C';
		}

		$weatherunit .= '</div><div class="wgroup"><hr>
			<div class="tsv" style="float: left; text-align: center; width: 33.3%"><strong>Temperature</strong><br>' . $temperature . '</div>
			<div class="tsv" style="float: left; text-align: center; width: 33.4%">Avg. Wind Speed: ' . $dailysummary->{'meanwindspdi'} . ' mph</div>
			<div class="tsv" style="float: left; text-align: center; width: 33.3%">Avg. Visibility: ' . $dailysummary->{'meanvisi'} . ' miles</div>
			</div>';

	    if ( 0 == strcmp($dailysummary->{'rain'}, "1") )
	    {
			if ( 0 == strcmp($dailysummary->{'snow'}, "1") ) {
				$weatherunit .= '<div class="rainsnow" style="float: left; text-align: center; width: 50%">Rainfall: ' . $dailysummary->{'precipi'} . '</div>
					<div class="rainsnow" style="float: left; text-align: center; width: 50%">Snowfall: ' . $dailysummary->{'snowfalli'} . '</div>';
			} else {
				$weatherunit .= '<div class="rain" style="text-align: center">Rainfall: ' . $dailysummary->{'precipi'} . '</div>';
			}
		} else {
			if ( 0 == strcmp($dailysummary->{'snow'}, "1") ) {
				$weatherunit .= '<div class="snow" style="text-align: center">Snowfall: ' . $dailysummary->{'snowfalli'} . '</div>';
			}
		}

		$weatherunit .= '</div>';
		return $weatherunit;
	}

	private function history_icon( $status, $size )
	{
		if ( 0 == strncmp($status, 'Light', 5) || 0 == strncmp($status, 'Heavy', 5) ) {
			$status = substr($status, 6);
		}
		$icons = array(
			'Drizzle'                       => 'wi-day-sprinkle',
			'Rain'                          => 'wi-day-rain',
			'Snow'                          => 'wi-day-snow',
			'Snow Grains'                   => 'wi-day-snow',
			'Ice Crystals'                  => 'wi-day-snow',
			'Ice Pellets'                   => 'wi-day-snow',
			'Hail'                          => 'wi-day-hail',
			'Mist'                          => 'wi-day-fog',
			'Fog'                           => 'wi-day-fog',
			'Fog Patches'                   => 'wi-day-fog',
			'Smoke'                         => 'wi-smoke',
			'Volcanic Ash'                  => 'wi-smog',
			'Widespread Dust'               => 'wi-dust',
			'Sand'                          => 'wi-dust',
			'Haze'                          => 'wi-smog',
			'Spray'                         => 'wi-day-sprinkle',
			'Dust Whirls'                   => 'wi-dust',
			'Sandstorm'                     => 'wi-tornado',
			'Low Drifting Snow'             => 'wi-day-snow',
			'Low Drifting Widespread Dust'  => 'wi-dust',
			'Low Drifting Sand'             => 'wi-dust',
			'Blowing Snow'                  => 'wi-day-snow-wind',
			'Blowing Widespread Dust'       => 'wi-dust',
			'Blowing Sand'                  => 'wi-dust',
			'Rain Mist'                     => 'wi-day-sprinkle',
			'Rain Showers'                  => 'wi-day-showers',
			'Snow Showers'                  => 'wi-day-snow',
			'Snow Blowing Snow Mist'        => 'wi-day-snow-wind',
			'Ice Pellet Showers'            => 'wi-day-hail',
			'Hail Showers'                  => 'wi-day-hail',
			'Small Hail Showers'            => 'wi-day-hail',
			'Thunderstorm'                  => 'wi-day-thunderstorm',
			'Thunderstorms and Rain'        => 'wi-day-storm-showers',
			'Thunderstorms and Snow'        => 'wi-day-snow-thunderstorm',
			'Thunderstorms and Ice Pellets' => 'wi-day-snow-thunderstorm',
			'Thunderstorms with Hail'       => 'wi-day-snow-thunderstorm',
			'Thunderstorms with Small Hail' => 'wi-day-snow-thunderstorm',
			'Freezing Drizzle'              => 'wi-day-rain-mix',
			'Freezing Rain'                 => 'wi-day-rain-mix',
			'Freezing Fog'                  => 'wi-day-fog',
			'Patches of Fog'                => 'wi-day-fog',
			'Shallow Fog'                   => 'wi-day-fog',
			'Partial Fog'                   => 'wi-day-fog',
			'Overcast'                      => 'wi-day-sunny-overcast',
			'Clear'                         => 'wi-day-sunny',
			'Partly Cloudy'                 => 'wi-day-cloudy',
			'Mostly Cloudy'                 => 'wi-day-cloudy',
			'Scattered Clouds'              => 'wi-day-cloudy',
			'Small Hail'                    => 'wi-day-snow',
			'Squalls'                       => 'wi-day-cloudy-gusts',
			'Funnel Cloud'                  => 'wi-tornado',
			'Unknown Precipitation'         => 'wi-day-rain',
			'Unknown'                       => 'wi-day-sunny'
		);
		return '<span style="font-size: ' . $size . 'px;" class="wi ' . $icons[$status] . '" aria-hidden="true"></span>';
	}
}

$eman_weather = new eman_weather();

add_action( 'wp_loaded', 'init_eman_weather_history' );
function init_eman_weather_history()
{
	if ( method_exists('eman_weather_history', 'history') ) {
		$eman_weather_history = new eman_weather_history();
	}
}